package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

import com.cg.bean.DoctorAppointment;
import com.cg.exception.NEWException;

public class HMSdaoimpl implements HMSdao {
Connection connection=null;
PreparedStatement statement =null;
	
	
	@Override
	public List<DoctorAppointment> basedOnProblem(DoctorAppointment doctor) throws NEWException {
		// TODO Auto-generated method stub
		return null;
	}

}
