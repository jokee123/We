package com.cg.dao;

import java.util.List;

import com.cg.bean.DoctorAppointment;
import com.cg.exception.NEWException;

public interface HMSdao {

	List<DoctorAppointment> basedOnProblem(DoctorAppointment doctor) throws NEWException;

}
