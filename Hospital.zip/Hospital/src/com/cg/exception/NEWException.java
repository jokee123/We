package com.cg.exception;

public class NEWException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NEWException(String message)
	{
		super(message);
	}

}
