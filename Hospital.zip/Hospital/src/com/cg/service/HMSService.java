package com.cg.service;

import java.util.List;

import com.cg.bean.DoctorAppointment;
import com.cg.exception.NEWException;

public interface HMSService {

	List<DoctorAppointment> basedOnProblem(DoctorAppointment doctor) throws NEWException;

}
