package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.bean.DoctorAppointment;
import com.cg.dao.HMSdao;
import com.cg.dao.HMSdaoimpl;
import com.cg.exception.NEWException;

public class HMSServiceImpl implements HMSService {
List<String> list=new ArrayList<>();
	HMSdao dao=new HMSdaoimpl();
	@Override
	public List<DoctorAppointment> basedOnProblem(DoctorAppointment doctor) throws NEWException {
		if(doctor.getProblemName().equals("heart")) {
			String doctorName="Dr.BrijeshKumar";
			String appointment="Approved";
			DoctorAppointment point= new DoctorAppointment();
			point.setDoctorName(doctorName);
			point.setAppointmentStatus(appointment);
		
		}
		return dao.basedOnProblem(doctor);
	}

}
