package com.cg.main;


import java.util.List;
import java.util.Scanner;

import com.cg.bean.DoctorAppointment;
import com.cg.exception.NEWException;
import com.cg.service.HMSService;
import com.cg.service.HMSServiceImpl;

public class UIMain {

	public static void main(String[] args) {
		
		Scanner scanner= new Scanner(System.in);
		HMSService service=null;
		System.out.println("Booking... ");
		System.out.println("1.book doctor");
		System.out.println("2.view doctor");
		System.out.println("3.Exit");
		Integer choice =scanner.nextInt();
		switch(choice) {
		case 1:
			scanner.nextLine();
			System.out.println("Enter the name of patient ");
			String name=scanner.nextLine();
			System.out.println("Enter the phone number");
			String number=scanner.nextLine();
			System.out.println("Enter the Email");
			String email=scanner.nextLine();
			System.out.println("Enter the age");
			Integer age=scanner.nextInt();
			scanner.nextLine();
			System.out.println("Enter gender");
			String gender=scanner.nextLine();
			System.out.println("ENter problem name");
			String problem=scanner.nextLine();
			DoctorAppointment doctor=new DoctorAppointment();
			doctor.setPatientName(name);
			doctor.setPhoneNumber(number);
			doctor.setEmail(email);
			doctor.setAge(age);
			doctor.setGender(gender);
			doctor.setProblemName(problem);
			List<DoctorAppointment> list;
			service=new HMSServiceImpl();
			try {
				list=service.basedOnProblem(doctor);
			} catch (NEWException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			break;
		case 2:
			System.out.println("viewing details..Enter ur Id");
			break;
		case 3:
			System.out.println("Thank you");
			System.exit(0);
			break;
			default:
				System.err.println("Enter the input between 1 to 3");
		break;
		}

	}

}
