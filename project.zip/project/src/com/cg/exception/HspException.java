package com.cg.exception;

public class HspException extends Exception{
public HspException(String message) {
	super(message);
	// TODO Auto-generated constructor stub
}
}
